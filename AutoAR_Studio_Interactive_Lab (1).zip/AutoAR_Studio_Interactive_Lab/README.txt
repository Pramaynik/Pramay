AUTOAR STUDIO — INTERACTIVE LAB PROTOTYPE

CONTENTS
- index.html: car studio, reaction-time test, voice explanations, and simplified animated engine lab
- mclaren_spider.glb: supplied 3D exterior model

RUN LOCALLY
1. Keep index.html and mclaren_spider.glb in the same folder.
2. Open index.html in a modern browser with an internet connection (the app loads model-viewer and Three.js from CDNs).
3. For reliable AR testing, publish over HTTPS (GitHub Pages is HTTPS).

PUBLISH TO YOUR EXISTING GITHUB PAGES REPOSITORY
1. Download and unzip this package.
2. Open your existing Pramaynik/Pramay repository.
3. Replace the repository's root index.html with this package's index.html.
4. Upload mclaren_spider.glb to the same root folder if it is not already there.
5. Commit changes and wait for GitHub Pages to redeploy.

FEATURE NOTES
- Car viewer uses the included GLB and model-viewer controls.
- The engine lab is a custom simplified animated teaching visualization. It is not a model of the actual McLaren engine and is not engineering-accurate.
- Paint edits attempt to recolor materials whose names resemble body-paint materials; results depend on the GLB material names.
- Part swap buttons currently select/demo build options; actual wheel/body-kit geometry swaps require compatible additional models.
- AR support depends on device/browser. Android may use Scene Viewer/WebXR. iPhone Quick Look commonly requires a USDZ asset; this package does not include USDZ conversion.
- Voice uses the browser's speechSynthesis feature and may use voices installed on the device.
- This prototype uses CDN scripts, so an internet connection is required for those libraries.
