AUTOAR STUDIO — MCLAREN EDITION

This folder contains the app and your McLaren 3D model:
- index.html
- mclaren_spider.glb
- RUN_AUTOAR.bat

RUN LOCALLY (WINDOWS)
1. Extract the whole ZIP to a normal folder (do not run it inside the ZIP preview).
2. Double-click RUN_AUTOAR.bat.
3. Keep the black terminal window open.
4. Your browser opens http://localhost:8765.
5. Internet is needed to load Three.js libraries from jsDelivr.

FREE HOSTING VIA GITHUB PAGES
1. Sign in to https://github.com/ and create a new PUBLIC repository, e.g. autoar-studio.
2. Choose Add file > Upload files.
3. Upload index.html and mclaren_spider.glb together from this folder. You may also upload README.txt.
4. Commit the upload.
5. Open repository Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
7. Wait for GitHub Pages to publish; open the URL shown on that Pages screen.

IMPORTANT
- index.html and mclaren_spider.glb must be in the same published folder.
- Do not upload only index.html.
- This uses a real imported GLB model. What can be recolored depends on the meshes/materials inside the model.
- The app supports model importing and build configuration; it does not simulate engine mechanics.
- This is a browser prototype, not a deployed native mobile AR app.
