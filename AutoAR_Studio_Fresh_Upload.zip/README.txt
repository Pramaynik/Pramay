AUTOAR STUDIO — FRESH UPLOAD PACKAGE

FILES AT ZIP ROOT:
- index.html
- mclaren_spider.glb

PUBLISH TO GITHUB PAGES:
1. Extract this ZIP on your computer.
2. Open https://github.com/Pramaynik/Pramay
3. Click Add file > Upload files.
4. Upload index.html and mclaren_spider.glb from this extracted folder into the repository ROOT (not into another folder).
5. If GitHub asks, confirm replacing index.html. Keep mclaren_spider.glb in the root.
6. Commit changes to main.
7. Wait 1–3 minutes, then open https://pramaynik.github.io/Pramay/ and press Ctrl+Shift+R.

The app loads model-viewer and Three.js from CDNs, so an internet connection is required. The engine is a simplified educational animation. The exterior GLB must be present at the exact path ./mclaren_spider.glb. AR depends on the device/browser; iPhone Quick Look generally needs a USDZ model, which is not included.
